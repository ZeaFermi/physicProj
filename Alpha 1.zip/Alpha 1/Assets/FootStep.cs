﻿using UnityEngine;
using System.Collections;

public class FootStep : MonoBehaviour {

	public AudioClip crashSoft;

	private AudioSource source;



	void Awake () {

		source = GetComponent<AudioSource>();
	}


	void OnCollisionEnter()
	{
		
			source.PlayOneShot(crashSoft);
	}

}
