﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletScript1 : MonoBehaviour {

	// Public variable 
	public int speed = 6;
	private Rigidbody2D bullet;

	// Function called once when the bullet is created
	void Start(){
		// Get the rigidbody component
		bullet = GetComponent<Rigidbody2D>();

		bullet.velocity = new Vector2 (-speed, bullet.velocity.y);
	}

	// Function called when the object goes out of the screen
void OnBecameInvisible() {
		// Destroy the bullet 
	Destroy(gameObject);
	} 


}
